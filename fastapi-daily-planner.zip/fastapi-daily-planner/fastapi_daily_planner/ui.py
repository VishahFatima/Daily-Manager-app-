import streamlit as st
import requests
from datetime import datetime
import os
from dotenv import load_dotenv

load_dotenv()

API_URL = "http://localhost:8000"

def login():
    st.sidebar.header("Login")
    username = st.sidebar.text_input("Username")
    password = st.sidebar.text_input("Password", type="password")
    if st.sidebar.button("Login"):
        response = requests.post(
            f"{API_URL}/login/",
            data={"username": username, "password": password},
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        if response.status_code == 200:
            token = response.json()["access_token"]
            st.session_state["token"] = token
            st.sidebar.success("Logged in successfully!")
        else:
            st.sidebar.error("Login failed")

def signup():
    st.sidebar.header("Sign Up")
    username = st.sidebar.text_input("New Username")
    password = st.sidebar.text_input("New Password", type="password")
    if st.sidebar.button("Sign Up"):
        response = requests.post(f"{API_URL}/signup/", json={"username": username, "password": password})
        if response.status_code == 200:
            st.sidebar.success("Account created successfully!")
        else:
            st.sidebar.error("Sign up failed")

def create_task():
    st.header("Create Task")
    title = st.text_input("Title")
    description = st.text_area("Description")
    due_date = st.date_input("Due Date")
    if st.button("Create Task"):
        response = requests.post(
            f"{API_URL}/tasks/",
            headers={"Authorization": f"Bearer {st.session_state['token']}"},
            json={"title": title, "description": description, "due_date": due_date.isoformat()}
        )
        if response.status_code == 200:
            st.success("Task created successfully!")
        else:
            st.error("Failed to create task")

def view_tasks():
    st.header("View Tasks")
    try:
        response = requests.get(
            f"{API_URL}/tasks/",
            headers={"Authorization": f"Bearer {st.session_state['token']}"}
        )
        if response.status_code == 200:
            tasks = response.json()
            for task in tasks:
                with st.expander(task["title"]):
                    st.write(task["description"])
                    if st.button("Delete Task", key=f"delete_{task['id']}"):
                        delete_task(task['id'])
                        st.experimental_rerun()  # Refresh the page to reflect deletion
        else:
            st.error("Failed to fetch tasks")
    except requests.exceptions.RequestException as e:
        st.error(f"Error connecting to the server: {e}")

def delete_task(task_id):
    try:
        response = requests.delete(
            f"{API_URL}/tasks/{task_id}",
            headers={"Authorization": f"Bearer {st.session_state['token']}"}
        )
        if response.status_code == 200:
            st.success("Task deleted successfully!")
            st.rerun()  # Refresh the page to reflect the deleted task
        else:
            st.error("Failed to delete task")
    except requests.exceptions.RequestException as e:
        st.error(f"Error connecting to the server: {e}")

def main():
    st.title("Daily Planner")
    
    if "token" not in st.session_state:
        st.sidebar.title("Welcome")
        login()
        st.sidebar.write("---")
        signup()
    else:
        st.sidebar.title("Logged in")
        create_task()
        st.write("---")
        view_tasks()
        
if __name__ == "__main__":
    main()